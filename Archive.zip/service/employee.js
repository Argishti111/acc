const express = require("express");
const router = express();
const pool = require("../config/connectionDB");

router.post("/", async (req,res)=> {
    let {companyId,ssn} = req.body;

    const result = await pool.query(`SELECT * FROM get_employees(${companyId},${ssn}::varchar)`);

    res.send(result)
});

// router.post("/add", (req,res) => {
//
// })

module.exports = router;