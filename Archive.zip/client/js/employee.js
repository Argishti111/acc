fetch("/employee",{
    method: "POST",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify({companyId: 1, ssn: '0'})
}).then(data => data.json())
    .then(dat => console.log(dat.rows));


// var xhttp = new XMLHttpRequest();
// xhttp.onreadystatechange = function() {
//     if (this.readyState == 4 && this.status == 200) {
//         // Typical action to be performed when the document is ready:
//         console.log(xhttp)
//     }
// };
//
// xhttp.open("POST", "/employee", true);
// xhttp.setRequestHeader("Content-Type", "application/json");
// xhttp.send(JSON.stringify({companyId: 1, ssn: '0'}));